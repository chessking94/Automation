"""email

Author: Ethan Hunt
Creation Date: 2023-07-xx

"""

# TODO: Sending email (with and without attachments)
# TODO: Monitoring an inbox

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def main():
    # Email login details
    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    smtp_username = 'chessking94@gmail.com'
    smtp_password = 'oaellzppleptrjht'  # app password, not the normal one

    # Email content
    sender_email = 'chessking94@gmail.com'
    receiver_email = 'eehunt94@gmail.com'
    subject = 'Test email from Python'
    body = 'This is a test email sent from Python.'

    # Construct the message
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = receiver_email
    message['Subject'] = subject
    message.attach(MIMEText(body))

    # Connect to the SMTP server
    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(smtp_username, smtp_password)
        server.sendmail(sender_email, receiver_email, message.as_string())


if __name__ == '__main__':
    main()
