NL = '\n'
BOOLEANS = [True, False]
VALID_DELIMS = [',', '\t', '|']
